#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define BLK_SIZE 4096
#define NUM_BLOCKS 64
#define NODE_SIZE 256
#define NODE_COUNT 80
#define NODE_TABLE_BLKS 5
#define NODES_PER_BLK (BLK_SIZE / NODE_SIZE)

#define BLK_SUPER 0
#define BLK_INODE_BITMAP 1
#define BLK_DATA_BITMAP 2
#define BLK_INODE_TABLE 3
#define BLK_DATA_START 8

#define FS_MAGIC 0xD34D

#pragma pack(push, 1)
typedef struct {
    uint16_t magic;
    uint32_t blk_size;
    uint32_t total_blks;
    uint32_t inode_bmap_blk;
    uint32_t data_bmap_blk;
    uint32_t inode_tbl_start;
    uint32_t data_blk_start;
    uint32_t inode_size;
    uint32_t inode_count;
    char reserved[4058];
} FSHeader;

typedef struct {
    uint32_t mode;
    uint32_t uid;
    uint32_t gid;
    uint32_t fsize;
    uint32_t atime;
    uint32_t ctime;
    uint32_t mtime;
    uint32_t dtime;
    uint32_t nlink;
    uint32_t blk_count;
    uint32_t direct_blk;
    uint32_t s_indirect;
    uint32_t d_indirect;
    uint32_t t_indirect;
    char reserved[156];
} FSInode;
#pragma pack(pop)

FILE *disk;
FSHeader header;
uint8_t inode_bmap[BLK_SIZE];
uint8_t data_bmap[BLK_SIZE];
int blk_usage[NUM_BLOCKS];
int issues_found = 0;
int apply_fixes = 0;

void log_msg(const char *label, const char *fmt, ...) {
    issues_found = 1;
    printf("[%s] ", label);
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
}

int check_bit(uint8_t *map, int idx) {
    return map[idx / 8] & (1 << (idx % 8));
}

void mark_bit(uint8_t *map, int idx) {
    map[idx / 8] |= (1 << (idx % 8));
}

void unmark_bit(uint8_t *map, int idx) {
    map[idx / 8] &= ~(1 << (idx % 8));
}

int is_data_blk_valid(int blk) {
    return blk >= BLK_DATA_START && blk < NUM_BLOCKS;
}

void load_superblock() {
    fseek(disk, BLK_SUPER * BLK_SIZE, SEEK_SET);
    fread(&header, sizeof(FSHeader), 1, disk);

    if (header.magic != FS_MAGIC) log_msg("Error", "Bad magic number.\n");
    if (header.blk_size != BLK_SIZE) log_msg("Error", "Block size mismatch.\n");
    if (header.total_blks != NUM_BLOCKS) log_msg("Error", "Block count mismatch.\n");

    if (header.inode_bmap_blk != BLK_INODE_BITMAP ||
        header.data_bmap_blk != BLK_DATA_BITMAP ||
        header.inode_tbl_start != BLK_INODE_TABLE ||
        header.data_blk_start != BLK_DATA_START) {
        log_msg("Error", "Wrong block mapping in header.\n");
    }

    if (header.inode_size != NODE_SIZE || header.inode_count > NODE_COUNT) {
        log_msg("Error", "Inode size/count invalid.\n");
    }
}

void load_bitmaps() {
    fseek(disk, BLK_INODE_BITMAP * BLK_SIZE, SEEK_SET);
    fread(inode_bmap, 1, BLK_SIZE, disk);
    fseek(disk, BLK_DATA_BITMAP * BLK_SIZE, SEEK_SET);
    fread(data_bmap, 1, BLK_SIZE, disk);
}

void save_bitmaps() {
    fseek(disk, BLK_INODE_BITMAP * BLK_SIZE, SEEK_SET);
    fwrite(inode_bmap, 1, BLK_SIZE, disk);
    fseek(disk, BLK_DATA_BITMAP * BLK_SIZE, SEEK_SET);
    fwrite(data_bmap, 1, BLK_SIZE, disk);
}

void verify_indirect(uint32_t blk, int level) {
    if (blk == 0 || level == 0) return;

    if (!is_data_blk_valid(blk)) {
        log_msg("Error", "Invalid indirect block %u\n", blk);
        return;
    }

    uint32_t links[BLK_SIZE / sizeof(uint32_t)];
    fseek(disk, blk * BLK_SIZE, SEEK_SET);
    fread(links, sizeof(uint32_t), BLK_SIZE / sizeof(uint32_t), disk);

    if (!check_bit(data_bmap, blk - BLK_DATA_START)) {
        log_msg("Fix", "Indirect block %u not marked used.\n", blk);
        if (apply_fixes) mark_bit(data_bmap, blk - BLK_DATA_START);
    }
    if (blk_usage[blk]++) {
        log_msg("Error", "Duplicate indirect block %u\n", blk);
    }

    for (int i = 0; i < BLK_SIZE / sizeof(uint32_t); i++) {
        if (links[i] != 0)
            verify_indirect(links[i], level - 1);
    }
}

void check_inodes() {
    for (int i = 0; i < NODE_COUNT; i++) {
        FSInode node;
        fseek(disk, (BLK_INODE_TABLE * BLK_SIZE) + (i * NODE_SIZE), SEEK_SET);
        fread(&node, sizeof(FSInode), 1, disk);

        int active = node.nlink > 0 && node.dtime == 0;

        if (active) {
            if (!check_bit(inode_bmap, i)) {
                log_msg("Fix", "Inode %d not marked used.\n", i);
                if (apply_fixes) mark_bit(inode_bmap, i);
            }

            int blk = node.direct_blk;
            if (is_data_blk_valid(blk)) {
                if (!check_bit(data_bmap, blk - BLK_DATA_START)) {
                    log_msg("Fix", "Block %d should be marked used.\n", blk);
                    if (apply_fixes) mark_bit(data_bmap, blk - BLK_DATA_START);
                }
                if (blk_usage[blk]++) {
                    log_msg("Error", "Block %d reused.\n", blk);
                }
            } else if (blk != 0) {
                log_msg("Error", "Inode %d points to invalid block %d\n", i, blk);
            }

            verify_indirect(node.s_indirect, 1);
            verify_indirect(node.d_indirect, 2);
            verify_indirect(node.t_indirect, 3);
        } else {
            if (check_bit(inode_bmap, i)) {
                log_msg("Fix", "Inode %d should be cleared.\n", i);
                if (apply_fixes) unmark_bit(inode_bmap, i);
            }
        }
    }
}

void clean_orphan_blocks() {
    for (int i = 0; i < NUM_BLOCKS - BLK_DATA_START; i++) {
        int abs_blk = i + BLK_DATA_START;
        if (check_bit(data_bmap, i) && blk_usage[abs_blk] == 0) {
            log_msg("Fix", "Orphan data block %d cleared.\n", abs_blk);
            if (apply_fixes) unmark_bit(data_bmap, i);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2 || argc > 3) {
        printf("Usage: %s <image.img> [--fix]\n", argv[0]);
        return 1;
    }

    if (argc == 3 && strcmp(argv[2], "--fix") == 0) {
        apply_fixes = 1;
    }

    disk = fopen(argv[1], apply_fixes ? "rb+" : "rb");
    if (!disk) {
        perror("File open failed");
        return 1;
    }

    memset(blk_usage, 0, sizeof(blk_usage));

    load_superblock();
    load_bitmaps();
    check_inodes();
    clean_orphan_blocks();

    if (apply_fixes) save_bitmaps();

    fclose(disk);

    if (!issues_found) {
        printf("FS Check Passed. No issues.\n");
    } else {
        printf("FS Check completed with issues/fixes.\n");
    }

    return 0;
}

