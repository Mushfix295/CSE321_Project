#ifndef HISTORY_H
#define HISTORY_H

void add_to_history(const char *cmd);
void show_history();

#endif