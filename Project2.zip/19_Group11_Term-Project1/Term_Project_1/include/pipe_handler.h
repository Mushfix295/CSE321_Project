#ifndef PIPE_HANDLER_H
#define PIPE_HANDLER_H

void handle_pipe(char *cmd);

#endif