#ifndef SIGNAL_HANDLER_H
#define SIGNAL_HANDLER_H

void setup_signal_handlers();

#endif