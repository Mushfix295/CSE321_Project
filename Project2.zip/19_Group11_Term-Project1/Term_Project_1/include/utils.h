#ifndef UTILS_H
#define UTILS_H

void trim_whitespace(char *str);

#endif