#ifndef PARSER_H
#define PARSER_H

char **parse_command(char *line);
char ***parse_pipeline(char *line);
char **split_by_semicolon(char *line);
char **split_by_and(char *line);

#endif