#ifndef EXECUTOR_H
#define EXECUTOR_H

void execute_command(char **args, int background);
void execute_pipeline(char ***commands);

#endif