#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "parser.h"

#define MAX_ARGS 64
typedef enum { DEFAULT, IN_QUOTE } ParseState;

char **parse_command(char *line) {
    char **args = malloc(MAX_ARGS * sizeof(char *));
    int i = 0;
    char *arg = malloc(strlen(line) + 1);
    int arg_pos = 0;
    ParseState state = DEFAULT;

    for (int j = 0; ; j++) {
        char c = line[j];

        if (state == DEFAULT) {
            if (c == '"') {
                state = IN_QUOTE;
            } else if (isspace(c) || c == '\0') {
                if (arg_pos > 0) {
                    arg[arg_pos] = '\0';
                    args[i++] = strdup(arg);
                    arg_pos = 0;
                }
                if (c == '\0') break;
            } else {
                arg[arg_pos++] = c;
            }
        } else if (state == IN_QUOTE) {
            if (c == '"') {
                state = DEFAULT;
            } else {
                if (c == '\\' && line[j+1] == 'n') {
                    arg[arg_pos++] = '\n';
                    j++;
                } else {
                    arg[arg_pos++] = c;
                }
            }
        }
    }

    free(arg);
    args[i] = NULL;
    return args;
}

char ***parse_pipeline(char *line) {
    char ***commands = malloc(64 * sizeof(char **));
    int i = 0;
    char *segment = strtok(line, "|");
    while (segment != NULL) {
        while (*segment == ' ') segment++;
        char *end = segment + strlen(segment) - 1;
        while (end > segment && (*end == ' ' || *end == '\n')) {
            *end = '\0';
            end--;
        }
        commands[i++] = parse_command(segment);
        segment = strtok(NULL, "|");
    }
    commands[i] = NULL;
    return commands;
}

char **split_by_semicolon(char *line) {
    char **cmds = malloc(64 * sizeof(char *));
    char *cmd = strtok(line, ";");
    int i = 0;
    while (cmd != NULL) {
        cmds[i++] = cmd;
        cmd = strtok(NULL, ";");
    }
    cmds[i] = NULL;
    return cmds;
}

char **split_by_and(char *line) {
    char **cmds = malloc(64 * sizeof(char *));
    char *cmd = strtok(line, "&&");
    int i = 0;
    while (cmd != NULL) {
        cmds[i++] = cmd;
        cmd = strtok(NULL, "&&");
    }
    cmds[i] = NULL;
    return cmds;
}

