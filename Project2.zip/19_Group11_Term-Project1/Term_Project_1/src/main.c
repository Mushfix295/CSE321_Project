#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.h"
#include "executor.h"
#include "signal_handler.h"
#include "history.h"

int main() {
    setup_signal_handlers();
    char *line = NULL;
    size_t len = 0;

    while (1) {
        printf("sh> ");
        if (getline(&line, &len, stdin) == -1) break;

        if (strcmp(line, "\n") == 0) continue; 

        add_to_history(line);

        char **and_commands = split_by_and(line);
        for (int i = 0; and_commands[i]; i++) {
            char **commands = split_by_semicolon(and_commands[i]);
            for (int j = 0; commands[j]; j++) {
                if (strchr(commands[j], '|')) {
                    char ***pipes = parse_pipeline(commands[j]);
                    execute_pipeline(pipes);
                } else {
                    char **args = parse_command(commands[j]);
                    if (args[0]) {
                        if (strcmp(args[0], "history") == 0) {
                            show_history();
                        } else {
                            execute_command(args, 0);
                        }
                    }
                }
            }
        }
    }

    free(line);
    return 0;
}

