#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/wait.h>
#include "executor.h"

void execute_command(char **args, int background) {
    pid_t pid = fork();
    if (pid == 0) {
        int in_redirect = -1, out_redirect = -1;
        char *new_args[64];
        int j = 0;

        for (int i = 0; args[i] != NULL; i++) {
            if (strcmp(args[i], "<") == 0) {
                in_redirect = open(args[++i], O_RDONLY);
                if (in_redirect < 0) {
                    perror("Input file open failed");
                    exit(1);
                }
                dup2(in_redirect, STDIN_FILENO);
                close(in_redirect);
            }
            else if (strcmp(args[i], ">") == 0) {
                out_redirect = open(args[++i], O_WRONLY | O_CREAT | O_TRUNC, 0644);
                if (out_redirect < 0) {
                    perror("Output file open failed");
                    exit(1);
                }
                dup2(out_redirect, STDOUT_FILENO);
                close(out_redirect);
            }
            else if (strcmp(args[i], ">>") == 0) {
                out_redirect = open(args[++i], O_WRONLY | O_CREAT | O_APPEND, 0644);
                if (out_redirect < 0) {
                    perror("Append file open failed");
                    exit(1);
                }
                dup2(out_redirect, STDOUT_FILENO);
                close(out_redirect);
            }
            else {
                new_args[j++] = args[i];
            }
        }

        new_args[j] = NULL;

        if (execvp(new_args[0], new_args) == -1) {
            perror("exec failed");
            exit(1);
        }
    } else if (!background) {
        waitpid(pid, NULL, 0);
    }
}

void execute_pipeline(char ***commands) {
    int in_fd = 0;               
    int fd[2];                   
    pid_t pid;
    int i = 0;
    int status;
    pid_t pids[64];              
    while (commands[i] != NULL) {
        // Set up a pipe only if there is a next command
        if (commands[i + 1] != NULL) {
            if (pipe(fd) == -1) {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
        }
        pid = fork();
        if (pid == 0) {
            
            if (in_fd != 0) {
                dup2(in_fd, STDIN_FILENO);
                close(in_fd);
            }
            if (commands[i + 1] != NULL) {
                close(fd[0]);  // Close unused read end
                dup2(fd[1], STDOUT_FILENO);
                close(fd[1]);
            }

            execvp(commands[i][0], commands[i]);
            perror("execvp failed");
            exit(1);
        } else if (pid < 0) {
            perror("fork failed");
            exit(1);
        }
        pids[i] = pid;

        // Close write end in parent
        if (commands[i + 1] != NULL) {
            close(fd[1]);
            if (in_fd != 0) close(in_fd);  
            in_fd = fd[0];                 
        }

        i++;
    }
    for (int j = 0; j < i; j++) {
        waitpid(pids[j], &status, 0);
    }
}















