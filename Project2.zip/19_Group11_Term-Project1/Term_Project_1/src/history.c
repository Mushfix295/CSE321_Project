#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define HISTORY_SIZE 100

char *history[HISTORY_SIZE];
int count = 0;

void add_to_history(const char *cmd) {
    if (count < HISTORY_SIZE) {
        history[count++] = strdup(cmd);
    }
}

void show_history() {
    for (int i = 0; i < count; i++) {
        printf("%d: %s", i + 1, history[i]);
    }
}