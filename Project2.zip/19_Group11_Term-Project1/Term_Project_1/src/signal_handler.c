#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include "signal_handler.h"

void sigint_handler(int signo) {
    write(STDOUT_FILENO, "\nsh> ", 5);
}

void setup_signal_handlers() {
    struct sigaction sa;
    sa.sa_handler = sigint_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;
    sigaction(SIGINT, &sa, NULL);
}